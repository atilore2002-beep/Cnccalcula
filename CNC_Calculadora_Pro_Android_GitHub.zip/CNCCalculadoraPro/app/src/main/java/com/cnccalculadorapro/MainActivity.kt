package com.cnccalculadorapro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

private val Bg = Color(0xFF101820)
private val Panel = Color(0xFF1B2934)
private val Accent = Color(0xFFFFA726)
private val Mint = Color(0xFF66D9B5)
private val Txt = Color(0xFFF2F5F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CncApp() }
    }
}

@Composable
fun CncApp() {
    var page by remember { mutableStateOf("Inicio") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        secondary = Mint, onBackground = Txt, onSurface = Txt
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Panel).padding(18.dp)) {
                    Text("CNC CALCULADORA PRO", color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("TORNO CNC · FANUC · VERSIÓN 1.0", color = Color.LightGray, fontSize = 11.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Inicio", "Mecanizado", "Conos", "Roscas", "FANUC").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Inicio" -> Icons.Default.Home
                                        "Mecanizado" -> Icons.Default.Speed
                                        "Conos" -> Icons.Default.ChangeHistory
                                        "Roscas" -> Icons.Default.Settings
                                        else -> Icons.Default.Code
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when(page) {
                    "Inicio" -> HomeScreen { page = it }
                    "Mecanizado" -> MachiningScreen()
                    "Conos" -> ConeScreen()
                    "Roscas" -> ThreadScreen()
                    "FANUC" -> FanucScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Panel de herramientas", color = Txt, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Selecciona el cálculo que necesitas", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        val items = listOf(
            Triple("Mecanizado", "RPM · Velocidad de corte · Avance", Icons.Default.Speed),
            Triple("Conos", "Ángulo · Conicidad · Diámetros", Icons.Default.ChangeHistory),
            Triple("Roscas", "Métrica · Paso · Profundidad teórica", Icons.Default.Settings),
            Triple("FANUC", "Códigos G/M y ciclos habituales", Icons.Default.Code)
        )
        items.forEach { (title, subtitle, icon) ->
            Card(
                onClick = { open(title) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, tint = Accent, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Txt, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Accent)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2B18))) {
            Column(Modifier.padding(16.dp)) {
                Text("Aviso de seguridad", color = Accent, fontWeight = FontWeight.Bold)
                Text("Comprueba siempre unidades, límites de máquina, herramienta, correctores, cero pieza y simulación antes de ejecutar un programa.", color = Txt, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, onValue: (String) -> Unit, suffix: String = "") {
    OutlinedTextField(
        value = value, onValueChange = onValue, label = { Text(label) },
        trailingIcon = { if (suffix.isNotEmpty()) Text(suffix, color = Mint, modifier = Modifier.padding(end = 8.dp)) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true, modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Txt, unfocusedTextColor = Txt,
            focusedBorderColor = Accent, unfocusedBorderColor = Color.Gray,
            focusedLabelColor = Accent, unfocusedLabelColor = Color.LightGray
        )
    )
}

fun number(s: String): Double? = s.replace(',', '.').toDoubleOrNull()

@Composable
fun ResultCard(title: String, result: String, detail: String = "") {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18352F)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title.uppercase(), color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(result, color = Txt, fontSize = 27.sp, fontWeight = FontWeight.Black)
            if (detail.isNotEmpty()) Text(detail, color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@Composable
fun MachiningScreen() {
    var vc by remember { mutableStateOf("180") }
    var diameter by remember { mutableStateOf("50") }
    var rpm by remember { mutableStateOf("") }
    var feed by remember { mutableStateOf("0.20") }
    var resultRpm by remember { mutableStateOf<Double?>(null) }
    var resultFeed by remember { mutableStateOf<Double?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Cálculo de mecanizado", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Velocidad de corte y revoluciones para torno", color = Color.LightGray)
        Field("Velocidad de corte Vc", vc, { vc = it }, "m/min")
        Field("Diámetro de trabajo", diameter, { diameter = it }, "mm")
        Button(onClick = {
            val v = number(vc); val d = number(diameter)
            resultRpm = if (v != null && d != null && v > 0 && d > 0) 1000.0 * v / (PI * d) else null
        }, modifier = Modifier.fillMaxWidth()) { Text("CALCULAR RPM") }
        resultRpm?.let { ResultCard("Revoluciones calculadas", "${it.roundToInt()} RPM", "Fórmula: n = (1000 × Vc) / (π × D)") }
        Divider(color = Color.DarkGray)
        Text("Avance por minuto", color = Txt, fontWeight = FontWeight.Bold)
        Field("Revoluciones del husillo", rpm, { rpm = it }, "rpm")
        Field("Avance por vuelta", feed, { feed = it }, "mm/vuelta")
        Button(onClick = {
            val n = number(rpm); val f = number(feed)
            resultFeed = if (n != null && f != null && n > 0 && f > 0) n * f else null
        }, modifier = Modifier.fillMaxWidth()) { Text("CALCULAR AVANCE") }
        resultFeed?.let { ResultCard("Avance de trabajo", "${"%.2f".format(it)} mm/min", "F = RPM × avance por vuelta") }
    }
}

@Composable
fun ConeScreen() {
    var d1 by remember { mutableStateOf("50") }
    var d2 by remember { mutableStateOf("30") }
    var length by remember { mutableStateOf("100") }
    var result by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Calculadora de conos", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Field("Diámetro mayor D", d1, { d1 = it }, "mm")
        Field("Diámetro menor d", d2, { d2 = it }, "mm")
        Field("Longitud del cono L", length, { length = it }, "mm")
        Button(onClick = {
            val a = number(d1); val b = number(d2); val l = number(length)
            result = if (a != null && b != null && l != null && a > b && b >= 0 && l > 0) {
                val half = atan((a-b)/(2*l)) * 180 / PI
                val included = 2*half
                val ratio = (a-b)/l
                "Semiángulo: %.4f°\nÁngulo incluido: %.4f°\nConicidad: 1 : %.4f".format(half, included, 1.0/ratio)
            } else null
        }, modifier = Modifier.fillMaxWidth()) { Text("CALCULAR CONO") }
        result?.let { ResultCard("Resultado", it, "Conicidad = (D − d) / L") }
    }
}

@Composable
fun ThreadScreen() {
    var major by remember { mutableStateOf("10") }
    var pitch by remember { mutableStateOf("1.5") }
    var result by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Rosca métrica ISO", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Estimación teórica básica para rosca exterior de perfil ISO de 60°.", color = Color.LightGray, fontSize = 12.sp)
        Field("Diámetro nominal", major, { major = it }, "mm")
        Field("Paso", pitch, { pitch = it }, "mm")
        Button(onClick = {
            val d = number(major); val p = number(pitch)
            result = if (d != null && p != null && d > 0 && p > 0) {
                val depth = 0.61343 * p
                val minor = d - 1.22687 * p
                "Profundidad radial teórica: %.3f mm\nDiámetro menor teórico: %.3f mm".format(depth, minor)
            } else null
        }, modifier = Modifier.fillMaxWidth()) { Text("CALCULAR ROSCA") }
        result?.let { ResultCard("Resultado aproximado", it, "Verifica tolerancia, clase y norma antes de mecanizar.") }
    }
}

@Composable
fun FanucScreen() {
    val rows = listOf(
        "G00" to "Posicionamiento rápido",
        "G01" to "Interpolación lineal con avance",
        "G02 / G03" to "Interpolación circular horario / antihorario",
        "G18" to "Plano XZ (habitual en torno)",
        "G20 / G21" to "Programación en pulgadas / milímetros",
        "G40 / G41 / G42" to "Cancelar / compensación nariz herramienta",
        "G70" to "Ciclo de acabado (según control)",
        "G71" to "Ciclo de desbaste longitudinal (según control)",
        "G72" to "Ciclo de desbaste frontal (según control)",
        "G76" to "Ciclo de roscado múltiple (sintaxis variable)",
        "G97 / G96" to "RPM fija / velocidad de corte constante",
        "M03 / M04 / M05" to "Husillo horario / antihorario / parar",
        "M08 / M09" to "Refrigerante conectar / desconectar",
        "M30" to "Fin y reinicio del programa"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Referencia FANUC", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Los códigos y formatos pueden variar según modelo, parámetros y fabricante de máquina.", color = Accent, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        rows.forEach { (code, desc) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(code, color = Mint, fontWeight = FontWeight.Bold, modifier = Modifier.width(115.dp))
                    Text(desc, color = Txt, fontSize = 13.sp)
                }
            }
        }
    }
}
